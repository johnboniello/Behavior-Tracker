---
layout: base.njk
title: Posts
permalink: /posts/
description: Research summaries and writeups from John Boniello.
---
<section class="wrap section">
  <h1>Posts</h1>
  {% if collections.posts.length %}
  <ul class="post-list">
    {%- for post in collections.posts %}
    <li class="post-list__item">
      <a class="post-list__title" href="{{ post.url }}">{{ post.data.title }}</a>
      <time class="post-list__date" datetime="{{ post.date | isoDate }}">{{ post.date | readableDate }}</time>
      {% if post.data.summary %}<p class="post-list__summary">{{ post.data.summary }}</p>{% endif %}
    </li>
    {%- endfor %}
  </ul>
  {% else %}
  <p class="muted">New posts will show up here once they're published.</p>
  {% endif %}
</section>

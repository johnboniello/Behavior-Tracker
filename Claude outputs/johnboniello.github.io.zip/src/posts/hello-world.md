---
layout: post.njk
title: Hello, world
date: 2026-09-01
summary: "The first post on the new site — what to expect here."
description: The first post on John Boniello's site.
---
This is the first post on the rebuilt site. Expect research roundups, practical
classroom tools, and notes from building things like the Behavior Referral Tracker.

More soon.
